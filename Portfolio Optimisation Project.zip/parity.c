#include <stdio.h>

int main(void)
{
    int x;
    printf("Please enter the number\n");
    printf("x = ");
    scanf("%d", &x);
   
    if ( x % 2 == 0)
    {
        printf("The number is even\n");
    }
    else
    {
        printf("The number is odd\n");
    }
}