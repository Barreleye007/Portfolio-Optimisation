#include <stdio.h>

int main(void)
{
  char answer[20];
  printf("What's your name?\n");
  scanf("%s",answer);
  printf("Welcome, %s\n", answer);
}