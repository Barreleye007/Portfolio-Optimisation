#include <stdio.h>

int main(void)
{
    long x,y,z;
    printf("Enter the numbers you want to add\n");
    printf("x = ");
    scanf("%li", &x);
    printf("y = ");
    scanf("%li", &y);
    z = x + y;
    printf("The sum of numbers is %li\n", z);
}