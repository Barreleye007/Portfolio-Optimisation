#include <stdio.h>

int string_length(char m[40]);

int main(void)
{
    char name[40];
    printf("Name: ");
    scanf("%s", name);
    int length = string_length(name);
    printf("%d\n", length);

}

int string_length(char m[40])
{
    int i = 0;
    while (m[i] != '\0')
    {
        i++;
    }
    return i;
}