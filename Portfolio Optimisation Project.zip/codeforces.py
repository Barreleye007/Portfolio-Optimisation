s=input()
n=len(s)
f=[0]*n
f[0]=-1
for i in range(1,n):
    f[i]=f[i-1]
    while f[i]>=0 and s[f[i]+1]!=s[i]:
        f[i]=f[f[i]]
    if(s[f[i]+1]==s[i]):
        f[i]=f[i]+1
if (f[n-1]+1)*2>n:
    print("YES\n"+s[0:f[n-1]+1])
else:
    print("NO")