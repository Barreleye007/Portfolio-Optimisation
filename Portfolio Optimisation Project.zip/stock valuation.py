cur_div = float(input("Enter the current dividend being paid out by the company: "))
exp_growth = float(input("Enter the expected growth rate of dividend in % "))/100
req_rate = float(input("Enter the minimum required rate of return in % "))/100
cmp = float(input("Enter the current market price of stock: "))
intr_value = (cur_div * (1 + exp_growth))/(req_rate - exp_growth)

print("Value of the stock should be {}".format(intr_value))

if cmp > intr_value:
    print("stock is OVERVALUED")
elif cmp < intr_value:
    print("stock is UNDERVALUED")
else:
    print("stock is valued FAIRLY")