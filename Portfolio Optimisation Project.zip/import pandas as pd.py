import pandas as pd

# Create the data for different sections
production_data = {
    "Metric": ["Total Production", "India Avg Yield", "J&K Contribution", "J&K Yield", "Global Benchmark (Netherlands)", "Global Benchmark (Belgium)"],
    "Value": ["2.316 million tonnes", "6–8 t/ha", "67%", "~13 t/ha", "~40 t/ha", "~46 t/ha"]
}

trade_data = {
    "Category": ["Imports (2023)", "Import Growth (2014–2023)", "Exports (2020–21)", "Export Growth (2014–2021)"],
    "Value": ["469,000 tonnes", "+3.8%", "USD 14.45 million", "+82%"]
}

employment_data = {
    "Region": ["Jammu & Kashmir", "Himachal Pradesh"],
    "People/Families Supported": ["~3.5 million people (~500,000–600,000 families)", "~200,000–300,000 families"]
}

supply_chain_gaps = {
    "Issue": ["Low Yield", "Post-Harvest Loss", "Import Dominance", "Infrastructure Deficiency"],
    "Details": [
        "6–13 t/ha vs 40–46 t/ha globally",
        "18–40% losses, $8–15B/year",
        "469,000 tonnes imported vs ~50–70k tonnes exported",
        "Cold chain & MSP issues"
    ]
}

recommendations = {
    "Recommendations": [
        "Expand cold-chain infrastructure under Operation Greens",
        "Introduce MSP protection & raise import duties",
        "Boost R&D via IIHR for yield improvements",
        "Promote sorting/packing/transport technology",
        "Enhance export logistics & reduce trade gap"
    ]
}

# Convert to DataFrames
df_production = pd.DataFrame(production_data)
df_trade = pd.DataFrame(trade_data)
df_employment = pd.DataFrame(employment_data)
df_gaps = pd.DataFrame(supply_chain_gaps)
df_recommendations = pd.DataFrame(recommendations)

# Create Excel writer
excel_filename = "India_Apple_Supply_Chain_Analysis.xlsx"
with pd.ExcelWriter(excel_filename, engine='xlsxwriter') as writer:
    df_production.to_excel(writer, sheet_name='Production', index=False)
    df_trade.to_excel(writer, sheet_name='Trade', index=False)
    df_employment.to_excel(writer, sheet_name='Employment', index=False)
    df_gaps.to_excel(writer, sheet_name='Supply Chain Gaps', index=False)
    df_recommendations.to_excel(writer, sheet_name='Recommendations', index=False)

print(f"Excel file '{excel_filename}' created successfully.")
