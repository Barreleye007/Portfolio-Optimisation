import turtle

screen = turtle.Screen()
screen.bgcolor("blue")
pen = turtle.Turtle()
pen.color("lightgreen")
pen.pensize(3)

pen.forward(100)
pen.right(90)
pen.forward(100)
turtle.done()